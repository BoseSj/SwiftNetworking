//
//  BasicSideMenuApp.swift
//  BasicSideMenu
//
//  Created by SJ Basak on 20/10/24.
//

import SwiftUI

@main
struct BasicSideMenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
