//
//  ContentView.swift
//  BasicSideMenu
//
//  Created by SJ Basak on 20/10/24.
//

import SwiftUI


struct ContentView: View {
    
    @State var showSideMenu: Bool = false
    
    var body: some View {
        ZStack {
            VStack {
                HStack {
                    Button {
                        showSideMenu.toggle()
                    }label: {
                        Image(systemName: "line.3.horizontal")
                            .imageScale(.large)
                            .foregroundStyle(.tint)
                            .padding()
                    }
                    
                    Spacer()
                }
                
                Spacer()
                Image(systemName: "globe")
                    .imageScale(.large)
                    .foregroundStyle(.tint)
                    .padding()
                Text("Hello, Sidemenu!")
                Spacer()
            }
            .padding()
            
            SideMenuVw(isShowing: $showSideMenu)
        }
    }
}

#Preview {
    ContentView()
}

