//
//  SideMenuRowView.swift
//  BasicSideMenu
//
//  Created by SJ Basak on 20/10/24.
//

import SwiftUI

struct SideMenuRowView: View {
    
    let option: SidemenuOptionDataModel
    
    @Binding var selectedOption: SidemenuOptionDataModel?
    
    var isSelected: Bool {
        selectedOption == option
    }
    
    var body: some View {
        HStack {
            Image(systemName: option.systemImageName)
                .imageScale(.small)
            
            Text(option.title)
                .font(.subheadline)
            
            Spacer()
        }
        .padding()
        .frame(width: 216, height: 44)
        .foregroundStyle(isSelected ? .blue : .primary)
        .background(isSelected ? .blue.opacity(0.15) : .clear)
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

#Preview {
    SideMenuRowView(option: .dashboard, selectedOption: .constant(.dashboard))
}
