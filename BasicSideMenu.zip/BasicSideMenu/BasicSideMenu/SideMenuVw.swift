//
//  SideMenuVw.swift
//  BasicSideMenu
//
//  Created by SJ Basak on 20/10/24.
//

import SwiftUI


struct SideMenuVw: View {
    
    @Binding var isShowing: Bool
    @State private var selectedOption: SidemenuOptionDataModel?
    
    @State private var toast: Toast? = nil
    
    var body: some View {
        ZStack {
            if isShowing {
                Rectangle()
                    .opacity(0.3)
                    .ignoresSafeArea()
                    .onTapGesture {
                        isShowing.toggle()
                    }
                
                HStack {
                    VStack(alignment: .leading, spacing: 32) {
                        SideMenuHeaderView()
                        
                        VStack {
                            ForEach(SidemenuOptionDataModel.allCases) { option in
                                Button {
                                    self.selectedOption = option
                                    
                                    toast = .init(
                                        style: .success,
                                        message: option.title
                                    )
                                } label: {
                                    SideMenuRowView(
                                        option: option,
                                        selectedOption: $selectedOption
                                    )
                                }
                            }
                        }
                        
                        Spacer()
                    }
                    .padding()
                    .frame(width: 270, alignment: .leading)
                    .background(.white)
                    
                    Spacer()
                }
                .transition(.move(edge: .leading))
            }
        }
        .animation(.easeInOut, value: self.isShowing)
        .toastView(toast: $toast)
    }
}

#Preview {
    SideMenuVw(isShowing: .constant(true))
}


