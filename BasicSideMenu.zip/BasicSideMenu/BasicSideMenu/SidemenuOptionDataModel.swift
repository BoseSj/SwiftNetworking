//
//  SidemenuDataModel.swift
//  BasicSideMenu
//
//  Created by SJ Basak on 20/10/24.
//

import Foundation


enum SidemenuOptionDataModel: Int, CaseIterable {
    case dashboard
    case profile
    case search
    case notification
    case history
    
    var title: String {
        switch self {
        case .dashboard:
            return "Dashboard"
        case .profile:
            return "Profile"
        case .search:
            return "Search"
        case .notification:
            return "Notification"
        case .history:
            return "History"
        }
    }
    
    var systemImageName: String {
        switch self {
        case .dashboard:
            return "filemenu.and.cursorarrow"
        case .profile:
            return "person"
        case .search:
            return "magnifyingglass"
        case .notification:
            return "bell.fill"
        case .history:
            return "clock.arrow.trianglehead.counterclockwise.rotate.90"
        }
    }
    
}

extension SidemenuOptionDataModel: Identifiable {
    var id: Int { rawValue }
}
