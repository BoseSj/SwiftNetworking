//
//  ToastView.swift
//  BasicSideMenu
//
//  Created by SJ Basak on 21/10/24.
//


import SwiftUI

struct ToastView: View {
  
  var style: ToastStyle
  var message: String
  var width = CGFloat.infinity
  var onCancelTapped: (() -> Void)
  
  var body: some View {
    HStack(alignment: .center, spacing: 12) {
      Image(systemName: style.iconFileName)
            .imageScale(.medium)
        
      Text(message)
        .font(.system(size: 17, weight: .semibold))
        .foregroundStyle(.white)
        
      Spacer(minLength: 10)
      
      Button {
        onCancelTapped()
      } label: {
        Image(systemName: "xmark")
              .imageScale(.medium)
              .foregroundStyle(.white)
      }
    }
    .padding()
    .frame(minWidth: 0, maxWidth: width)
    .background(Color.gray)
    .cornerRadius(8)
    .overlay(
      RoundedRectangle(cornerRadius: 8)
        .opacity(0.2)
    )
    .padding(.horizontal, 16)
  }
}
