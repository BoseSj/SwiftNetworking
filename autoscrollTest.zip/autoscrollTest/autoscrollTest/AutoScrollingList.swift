//
//  AutoScrollingList.swift
//  autoscrollTest
//
//  Created by SJ Basak on 16/11/24.
//

import SwiftUI

struct AutoScrollingList: View {
    @State private var scrollToIndex = 0
    @State private var isScrollingDown = true
    let totalItems = 300 // Number of items in your repeated list

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(spacing: 20) {
                    ForEach(0..<totalItems, id: \.self) { index in
                        Button("Button \(index + 1)") {
                            // Button action if needed
                        }
                        .frame(height: 50)
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                }
                .onAppear {
                    startScrolling(proxy: proxy)
                }
            }
        }
    }

    private func startScrolling(proxy: ScrollViewProxy) {
        // The animation pattern: down (2s), up (2s), down (2s), and stop
        let animationSteps = [
            (index: 2, duration: 2.0), // Scroll down to index 2
            (index: 0, duration: 2.0), // Scroll back to index 0
            (index: 2, duration: 2.0)  // Scroll down to index 2
        ]

        var step = 0
        func performStep() {
            if step < animationSteps.count {
                let target = animationSteps[step]
                withAnimation(.easeInOut(duration: target.duration)) {
                    proxy.scrollTo(target.index, anchor: .center)
                }
                step += 1
                DispatchQueue.main.asyncAfter(deadline: .now() + target.duration) {
                    performStep()
                }
            }
        }

        performStep()
    }
}

struct AutoScrollingList_Previews: PreviewProvider {
    static var previews: some View {
        AutoScrollingList()
    }
}
