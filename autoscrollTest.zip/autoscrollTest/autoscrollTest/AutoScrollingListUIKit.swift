//
//  AutoScrollingListUIKit.swift
//  autoscrollTest
//
//  Created by SJ Basak on 16/11/24.
//

import SwiftUI


struct AutoScrollingListUIKit: UIViewRepresentable {
    let itemCount: Int // Number of items in the list
    
    func makeUIView(context: Context) -> UIScrollView {
        let scrollView = UIScrollView()
        scrollView.isPagingEnabled = false
        scrollView.showsVerticalScrollIndicator = false
        
        // Create the stack view with buttons
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.spacing = 20
        
        // Add buttons to the stack view
        for index in 1...itemCount {
            let button = UIButton(type: .system)
            button.setTitle("Button \(index)", for: .normal)
            button.backgroundColor = .blue
            button.setTitleColor(.white, for: .normal)
            button.layer.cornerRadius = 10
            button.translatesAutoresizingMaskIntoConstraints = false
            button.heightAnchor.constraint(equalToConstant: 50).isActive = true
            button.widthAnchor.constraint(equalToConstant: 200).isActive = true
            stackView.addArrangedSubview(button)
        }
        
        // Add stack view to scroll view
        stackView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(stackView)
        
        // Layout constraints for stack view
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            stackView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            stackView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            stackView.widthAnchor.constraint(equalTo: scrollView.widthAnchor)
        ])
        
        // Start the scrolling animation
        DispatchQueue.main.async {
            context.coordinator.startScrolling(scrollView: scrollView, itemHeight: 70)
        }
        
        return scrollView
    }
    
    func updateUIView(_ uiView: UIScrollView, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }
    
    class Coordinator {
        func startScrolling(scrollView: UIScrollView, itemHeight: CGFloat) {
            let animationDuration: TimeInterval = 2.0
            
            // Scroll down
            UIView.animate(withDuration: animationDuration, delay: 0, options: [.curveEaseInOut]) {
                scrollView.setContentOffset(CGPoint(x: 0, y: itemHeight * 2), animated: false)
            } completion: { _ in
                // Scroll back up
                UIView.animate(withDuration: animationDuration, delay: 0, options: [.curveEaseInOut]) {
                    scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: false)
                } completion: { _ in
                    // Scroll down and stop
                    UIView.animate(withDuration: animationDuration, delay: 0, options: [.curveEaseInOut]) {
                        scrollView.setContentOffset(CGPoint(x: 0, y: itemHeight * 2), animated: false)
                    }
                }
            }
        }
    }
}
