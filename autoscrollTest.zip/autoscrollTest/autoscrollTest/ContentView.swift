//
//  ContentView.swift
//  autoscrollTest
//
//  Created by SJ Basak on 16/11/24.
//

import SwiftUI


struct ContentView: View {
    var body: some View {
        VStack {
            FilmReelAutoScrollView()
                .frame(maxHeight: .infinity)
                .ignoresSafeArea()
        }
    }
}
