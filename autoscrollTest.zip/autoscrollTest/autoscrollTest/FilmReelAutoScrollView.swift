//
//  FilmReelAutoScrollView.swift
//  autoscrollTest
//
//  Created by SJ Basak on 18/11/24.
//

import SwiftUI
import UIKit

struct FilmReelAutoScrollView: UIViewRepresentable {
    func makeUIView(context: Context) -> UIScrollView {
        let scrollView = UIScrollView()
        scrollView.showsVerticalScrollIndicator = false
        scrollView.isPagingEnabled = false
        scrollView.bounces = false

        // Embed the SwiftUI view in a hosting controller
        let hostingController = UIHostingController(rootView: FilmReelButtonList())
        let hostingView = hostingController.view!
        hostingView.translatesAutoresizingMaskIntoConstraints = false

        // Add the SwiftUI view to the scroll view
        scrollView.addSubview(hostingView)

        // Set up constraints for the SwiftUI view
        NSLayoutConstraint.activate([
            hostingView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            hostingView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            hostingView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            hostingView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            hostingView.widthAnchor.constraint(equalTo: scrollView.widthAnchor)
        ])

        // Start auto-scroll animation
        DispatchQueue.main.async {
            context.coordinator.startScrolling(scrollView: scrollView)
        }

        return scrollView
    }

    func updateUIView(_ uiView: UIScrollView, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    class Coordinator {
        func startScrolling(scrollView: UIScrollView) {
            let scrollHeight = scrollView.contentSize.height
            let visibleHeight = scrollView.frame.height
            let maxOffset = max(0, scrollHeight - visibleHeight)

            guard maxOffset > 0 else { return }

            let scrollDuration: TimeInterval = 2.0

            UIView.animate(withDuration: scrollDuration, delay: 0, options: [.curveEaseInOut]) {
                scrollView.setContentOffset(CGPoint(x: 0, y: maxOffset / 2), animated: false)
            } completion: { _ in
                UIView.animate(withDuration: scrollDuration, delay: 0, options: [.curveEaseInOut]) {
                    scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: false)
                } completion: { _ in
                    UIView.animate(withDuration: scrollDuration, delay: 0, options: [.curveEaseInOut]) {
                        scrollView.setContentOffset(CGPoint(x: 0, y: maxOffset / 2), animated: false)
                    }
                }
            }
        }
    }
}
