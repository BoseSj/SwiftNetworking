//
//  FilmReelButtons.swift
//  autoscrollTest
//
//  Created by SJ Basak on 17/11/24.
//

import SwiftUI

struct FilmReelButtons: View {
    var body: some View {
        ZStack {
            HStack(spacing: 15) {
                VStack {
                    ForEach(0..<14) { _ in
                        SmallReelRectangle()
                    }
                }
                
                VStack {
                    ForEach(0..<3) { _ in
                        ReelImage()
                    }
                }
                
                VStack {
                    ForEach(0..<14) { _ in
                        SmallReelRectangle()
                    }
                }
            }
            .padding(.horizontal, 15)
        }
        .background(.gray)
    }
}


struct FilmReelButtonList: View {
    
    var body: some View {
        HStack {
            Spacer()
            
            VStack(spacing: 0) {
                ScrollView() {
                    ForEach(0..<20) { _ in
                        FilmReelButtons()
                            .padding(.top, -15)
                    }
                }
            }
            .frame(width: 180)
            .padding(.trailing, 30)
            .ignoresSafeArea()
        }
    }
}


#Preview {
    FilmReelButtonList()
}

struct SmallReelRectangle: View {
    var body: some View {
        Rectangle()
            .foregroundStyle(.white)
            .frame(width: 15, height: 15)
    }
}

struct ReelImage: View {
    var body: some View {
        Image(systemName: "person.and.background.dotted")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .padding(.vertical, 15)
            .background {
                Color.red.opacity(0.86)
            }
    }
}
