//
//  autoscrollTestApp.swift
//  autoscrollTest
//
//  Created by SJ Basak on 16/11/24.
//

import SwiftUI

@main
struct autoscrollTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
